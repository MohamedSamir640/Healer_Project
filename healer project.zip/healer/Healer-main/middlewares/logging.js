const logging = (req, res, next) => {
    console.log(`Request made at ${new Date()} for ${req.method} ${req.path}`);
    console.log(`Headers: ${JSON.stringify(req.headers)}`);
    console.log(`Body: ${JSON.stringify(req.body)}`);
    next();
};
module.exports = logging;

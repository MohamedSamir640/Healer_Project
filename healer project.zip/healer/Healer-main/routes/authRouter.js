const express = require('express');
const router = express.Router();

const {
    signUp,
    loginWithId,
    loginWithEmail,
    forgotPassword,
    resetPassword, 
} = require('../controllers/authController.js');

const {
    signUpValidator,
    loginValidator,
    resetPasswordValidator
} = require('../utils/validators/authValidator.js');

router.route('/signUp').post(signUpValidator, signUp);
router.route('/loginWithId').post(loginValidator, loginWithId);
router.route('/loginWithEmail').post(loginValidator, loginWithEmail);
router.route('/forgotPassword').post(forgotPassword);
router.route('/resetPassword').patch(resetPasswordValidator, resetPassword);

module.exports = router;

const nodemailer = require('nodemailer');

const sendEmail = async (option) => {
    try {
        if (!option.email || !option.subject || (!option.message && !option.html)) {
            throw new Error('Missing required email options.');
        }

        const transporter = nodemailer.createTransport({
            host: process.env.EMAIL_HOST,
            port: process.env.EMAIL_PORT,
            secure: process.env.EMAIL_PORT === '465', // Use TLS if port is 465
            auth: {
                user: process.env.EMAIL,
                pass: process.env.EMAIL_PASSWORD,
            },
            tls: {
                rejectUnauthorized: false,
            },
        });

        const emailOptions = {
            from: `"Your App" <${process.env.EMAIL}>`, // Customizable sender name
            to: option.email,
            subject: option.subject,
            text: option.message || null,
            html: option.html || null, // Supports HTML content
        };

        await transporter.sendMail(emailOptions);
        console.log('Email sent successfully!');
    } catch (err) {
        console.error('Error sending email:', err.message);
        throw new Error('Could not send the email. Please try again later.');
    }
};

module.exports = sendEmail;
